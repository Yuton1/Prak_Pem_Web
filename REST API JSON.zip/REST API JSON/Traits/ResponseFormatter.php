<?php

namespace Traits;

trait ResponseFormatter {
    public function responseFormatter($data, $message = 'Success') {
        return json_encode([
            'status' => 'success',
            'message' => $message,
            'data' => $data
        ]);
    }

}
?>
